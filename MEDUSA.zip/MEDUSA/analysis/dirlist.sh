#!/bin/bash

dirlist=(
#s12_full_l2n5x2_gr
#s12_rbrp_l2n5x2_gr
#s15_full_l2n5x2_gr
#s15_rbrp_l2n5x2_gr
#s20_full_l2n5x2_gr
#s20_rbrp_l2n5x2_gr
s25_full_l2n5x2_gr
#s25_rbrp_l2n5x2_gr
s25_full_l2n5x2_gr_lores
s25_rbrp_l2n5x2_gr_lores
s25_full_l2n5x2_gr_hires
s25_rbrp_l2n5x2_gr_hires
)

