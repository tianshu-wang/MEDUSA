dump_dir   = "../dumps/"
tbounce    = 
dump_start = 
dump_stop  = 
model      = 
eos        = 'LS220'
method     = 'Multi-D'
gravity    = 'GR mono'
Nr         = 608
nproc      = 1024
perturb    = 'l2n5x2'
title_text = 's25, full, l=2, n=5, dv=1000, GR mono'
save_text  = 's25_full_LS220e2_Nr608_p1024_l2n5x2_grmono'
